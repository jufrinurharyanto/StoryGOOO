package com.example.storygoo.main

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.storygoo.Detail.DetailActivity
import com.example.storygoo.LoadingStateAdapter
import com.example.storygoo.R
import com.example.storygoo.StoryListAdapter
import com.example.storygoo.databinding.ActivityMainBinding
import com.example.storygoo.map.MapsActivity
import com.example.storygoo.pref.ViewModelFactory
import com.example.storygoo.upload.UploadActivity
import com.example.storygoo.welcome.WelcomeActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var binding: ActivityMainBinding

    private lateinit var adapter: StoryListAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val progressBarDelayMillis = 2000 // Adjust delay time as needed

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupView()
        setMainMenu()
        setupBottomNavigation()

        val layoutManager = LinearLayoutManager(this)
        binding.rvStoriesList.layoutManager = layoutManager

        handler.postDelayed({
            viewModel.getSession().observe(this) { user ->
                if (!user.isLogin) {
                    startActivity(Intent(this, WelcomeActivity::class.java))
                    finish()
                } else {
                    getData()
                }
            }
        }, 500)

        // Automatically select "Home" item in bottom navigation
        binding.navButton.selectedItemId = R.id.home
    }

    override fun onResume() {
        super.onResume()

        // Check if coming back from MapsActivity or UploadActivity
        val intent = intent
        if (intent != null && (intent.hasExtra("fromMapsActivity") || intent.hasExtra("fromUploadActivity"))) {
            // Automatically select "Home" item in bottom navigation
            binding.navButton.selectedItemId = R.id.home
        }
    }

    @Suppress("DEPRECATION")
    private fun setupBottomNavigation() {
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.nav_button)

        // Handle item reselection to scroll to top or animate back to home
        bottomNavigationView.setOnNavigationItemReselectedListener { item ->
            when (item.itemId) {
                R.id.home -> scrollToTop()
                else -> animateToHome()
            }
        }

        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home -> {
                    // Check if already in MainActivity, if not, start MainActivity
                    if (!isMainActivityCurrent()) {
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    } else {
                        // If already in MainActivity, just scroll to top
                        scrollToTop()
                    }
                    true
                }

                R.id.add_nav -> {
                    val intent = Intent(this, UploadActivity::class.java)
                    startActivity(intent)
                    bottomNavigationView.selectedItemId = R.id.home // Set home as selected
                    true
                }

                R.id.action_maps -> {
                    val intent = Intent(this, MapsActivity::class.java)
                    startActivity(intent)
                    bottomNavigationView.selectedItemId = R.id.home // Set home as selected
                    true
                }

                else -> false
            }
        }
    }

    private fun isMainActivityCurrent(): Boolean {
        return this::class.java.simpleName == MainActivity::class.java.simpleName
    }

    private fun scrollToTop() {
        binding.rvStoriesList.smoothScrollToPosition(0)
    }

    private fun animateToHome() {
        val animDuration = 250L // Adjust animation duration as needed
        binding.navButton.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(animDuration)
            .start()
    }

    private fun getData() {
        showLoading(true)

        adapter = StoryListAdapter { story ->
            val intent = Intent(this, DetailActivity::class.java).apply {
                putExtra("storyId", story.id)
            }
            startActivity(intent)
        }

        binding.rvStoriesList.adapter = adapter.withLoadStateFooter(
            footer = LoadingStateAdapter {
                adapter.retry()
            }
        )
        viewModel.storyList.observe(this) {
            adapter.submitData(lifecycle, it)
            showLoading(false)
        }
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setMainMenu() {
        binding.topAppBar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.logout -> {
                    AlertDialog.Builder(this).apply {
                        setTitle(getString(R.string.logout))
                        setMessage(getString(R.string.logout_message))
                        setPositiveButton(R.string.yes) { _, _ ->
                            viewModel.logout()
                        }
                        setNegativeButton(R.string.no) { dialog, _ ->
                            dialog.dismiss()
                        }
                        create()
                        show()
                    }
                    true
                }

                else -> false
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}
