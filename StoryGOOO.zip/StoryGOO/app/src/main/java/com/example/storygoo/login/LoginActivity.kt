package com.example.storygoo.login

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.storygoo.pref.ViewModelFactory
import com.example.storygoo.R
import com.example.storygoo.databinding.ActivityLoginBinding
import com.example.storygoo.main.MainActivity
import com.example.storygoo.pref.Result
import com.example.storygoo.pref.UserModel

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    private val viewModel by viewModels<LoginViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupView()
        setupAction()
        playAnimation()
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupAction() {
        binding.loginButton.setOnClickListener {
            val email = binding.emailEditText.text.toString()
            val password = binding.passwordEditText.text.toString()

            if (password.length < 8) {
                binding.passwordEditText.error = getString(R.string.password_error)
                return@setOnClickListener
            } else {
                binding.passwordEditText.error = null
            }

            viewModel.login(email, password).observe(this) { result ->
                if (result != null) {
                    when (result) {
                        is Result.Loading -> {
                            showLoading(true)
                        }

                        is Result.Success -> {
                            showLoading(false)
                            val loginResponse = result.data
                            showToast(loginResponse.message)

                            val userModel = UserModel(
                                email = email,
                                token = loginResponse.loginResult.token,
                                isLogin = true
                            )
                            viewModel.saveSession(userModel)

                            AlertDialog.Builder(this).apply {
                                setTitle(getString(R.string.success))
                                setMessage(getString(R.string.success_login))
                                setPositiveButton(getString(R.string.next)) { _, _ ->
                                    val intent = Intent(context, MainActivity::class.java)
                                    intent.flags =
                                        Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                    startActivity(intent)
                                    finish()
                                }
                                create()
                                show()
                            }
                        }

                        is Result.Error -> {
                            showLoading(false)
                            showToast(result.error)
                        }
                    }
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.imgL, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val login = ObjectAnimator.ofFloat(binding.loginButton, View.ALPHA, 1f).setDuration(2000)
        val title = ObjectAnimator.ofFloat(binding.textInImage, View.ALPHA, 1f).setDuration(2000)
        val desc = ObjectAnimator.ofFloat(binding.textInImage2, View.ALPHA, 1f).setDuration(2000)
        val newText = ObjectAnimator.ofFloat(binding.newText, View.ALPHA, 1f).setDuration(2000)
        val newText1 = ObjectAnimator.ofFloat(binding.newText1, View.ALPHA, 1f).setDuration(2000)

        val together = AnimatorSet().apply {
            playTogether(login, newText, newText1)
        }
        AnimatorSet().apply {
            playSequentially(title, desc, together, newText, newText1)
            start()
        }
    }
}
