package com.example.storygoo.signup

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.storygoo.R
import com.example.storygoo.databinding.ActivitySignUpBinding
import com.example.storygoo.pref.Result
import com.example.storygoo.pref.ViewModelFactory

class SignUpActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignUpBinding

    private val viewModel by viewModels<SignupViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupView()
        setupAction()
        playAnimation()

        binding.registerEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!isValidEmail(s.toString())) {
                    binding.registerEmail.error = getString(R.string.email_error)
                } else {
                    binding.registerEmail.error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        binding.registerPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val password = s.toString()
                if (password.length < 8) {
                    binding.registerPassword.error = getString(R.string.password_error)
                } else {
                    binding.registerPassword.error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun isValidEmail(email: String): Boolean {
        val emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(?:\\.\\p{L}{2,})?\$"
        return email.matches(emailPattern.toRegex())
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupAction() {
        binding.registerButton.setOnClickListener {
            val name = binding.registerName.text.toString()
            val email = binding.registerEmail.text.toString()
            val password = binding.registerPassword.text.toString()

            viewModel.signup(name, email, password).observe(this) { result ->
                if (result != null) {
                    when (result) {
                        is Result.Loading -> showLoading(true)
                        is Result.Success -> {
                            showToast(result.data.message)
                            showLoading(false)
                            AlertDialog.Builder(this).apply {
                                setTitle(getString(R.string.success))
                                setMessage(getString(R.string.success_create_acc))
                                setPositiveButton(getString(R.string.continue_login)) { _, _ ->
                                    finish()
                                }
                                create()
                                show()
                            }
                        }

                        is Result.Error -> {
                            showToast(result.error)
                            showLoading(false)
                        }
                    }
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun playAnimation() {
        val textAnimation =
            ObjectAnimator.ofFloat(binding.newText, View.TRANSLATION_X, 800f, 0f).apply {
                duration = 1500
                interpolator = AccelerateDecelerateInterpolator()
            }

        val textAnimation1 =
            ObjectAnimator.ofFloat(binding.newText1, View.TRANSLATION_X, -800f, 0f).apply {
                duration = 1500
                interpolator = AccelerateDecelerateInterpolator()
            }

        val image2l = ObjectAnimator.ofFloat(binding.img2L, View.TRANSLATION_X, 0f, -800f).apply {
            duration = 40000
            interpolator = AccelerateDecelerateInterpolator()
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }

        val registerButtonAnimation =
            ObjectAnimator.ofFloat(binding.registerButton, View.ALPHA, 0f, 1f).apply {
                duration = 2000
                interpolator = AccelerateDecelerateInterpolator()
            }

        val gooTextAnimation =
            ObjectAnimator.ofFloat(binding.textInImage2, View.ALPHA, 0f, 1f).apply {
                duration = 2500
                interpolator = AccelerateDecelerateInterpolator()
            }

        AnimatorSet().apply {
            playTogether(
                textAnimation,
                textAnimation1,
                image2l,
                registerButtonAnimation,
                gooTextAnimation
            )
            startDelay = 500
            start()
        }
    }
}
