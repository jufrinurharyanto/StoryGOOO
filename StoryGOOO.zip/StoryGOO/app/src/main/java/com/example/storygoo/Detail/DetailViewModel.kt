package com.example.storygoo.Detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.storygoo.pref.Result
import com.example.storygoo.pref.UserModel
import com.example.storygoo.pref.UserRepository
import com.example.storygoo.response.Story

class DetailViewModel(private val userRepository: UserRepository) : ViewModel() {

    fun getSession(): LiveData<UserModel> {
        return userRepository.getSession().asLiveData()
    }

    fun getStoryById(token: String, id: String): LiveData<Result<Story>> {
        return userRepository.getStoryById(token, id)
    }
}