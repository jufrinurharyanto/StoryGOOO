package com.example.storygoo.upload

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.storygoo.R
import com.example.storygoo.databinding.ActivityUploadBinding
import com.example.storygoo.main.MainActivity
import com.example.storygoo.pref.Result
import com.example.storygoo.pref.ViewModelFactory
import com.example.storygoo.pref.reduceFileImage
import com.example.storygoo.pref.uriToFile
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

class UploadActivity : AppCompatActivity() {

    private val viewModel by viewModels<UploadViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var binding: ActivityUploadBinding

    private var currentImageUri: Uri? = null

    private var location: Location? = null

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            when {
                permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false -> {
                    addLocation()
                }

                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false -> {
                    addLocation()
                }

                permissions[Manifest.permission.CAMERA] ?: false -> {
                    startCamera()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = getString(R.string.title_upload)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.galleryButton.setOnClickListener { startGallery() }
        binding.uploadButton.setOnClickListener { uploadStory() }
        binding.cameraButton.setOnClickListener { startCamera() }
        binding.switchLocation.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!isGPSEnabled()) {
                    showEnableGPSDialog()
                }
                lifecycleScope.launch {
                    addLocation()
                }
            } else {
                location = null
            }
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
    }

    private fun startGallery() {
        if (checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE)) {
            launcherGallery.launch("image/*")
        } else {
            requestStoragePermission()
        }
    }

    private val launcherGallery = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            currentImageUri = uri
            showImage()
        }
    }

    private fun startCamera() {
        if (checkPermission(Manifest.permission.CAMERA)) {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            launcherCamera.launch(intent)
        } else {
            requestCameraPermission()
        }
    }

    private val launcherCamera = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            val imageBitmap = data?.extras?.get("data") as Bitmap?
            imageBitmap?.let {
                binding.previewImageView.setImageBitmap(it)
                currentImageUri = bitmapToUri(it)
            }
        }
    }

    private fun requestCameraPermission() {
        requestPermissionLauncher.launch(
            arrayOf(Manifest.permission.CAMERA)
        )
    }

    private fun showImage() {
        currentImageUri?.let {
            binding.previewImageView.setImageURI(it)
        }
    }

    private fun uploadStory() {
        val description = binding.descEditText.text.toString().trim()

        if (description.isEmpty()) {
            binding.descLayout.error = getString(R.string.empty_description_warning)
            return
        } else {
            binding.descLayout.error = null
        }

        if (currentImageUri != null) {
            val imageFile = uriToFile(currentImageUri!!, this)?.reduceFileImage()

            viewModel.getSession().observe(this) { user ->
                val token = user.token
                imageFile?.let {
                    viewModel.uploadStory(token, it, description, location)
                        .observe(this) { result ->
                            when (result) {
                                is Result.Loading -> {
                                    showLoading(true)
                                }

                                is Result.Success -> {
                                    showToast(result.data.message)
                                    showLoading(false)
                                    startActivity(Intent(this, MainActivity::class.java))
                                    finish() // Close UploadActivity after upload
                                }

                                is Result.Error -> {
                                    showToast(result.error)
                                    showLoading(false)
                                }

                                else -> {}
                            }
                        }
                } ?: showToast(getString(R.string.error_file))
            }
        } else {
            showToast(getString(R.string.empty_image_warning))
        }
    }

    private fun checkPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestStoragePermission() {
        requestPermissionLauncher.launch(
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        )
    }

    @SuppressLint("MissingPermission")
    private fun addLocation() {
        if (checkPermission(Manifest.permission.ACCESS_FINE_LOCATION) &&
            checkPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
        ) {
            fusedLocationClient.lastLocation.addOnSuccessListener { loc: Location? ->
                if (loc != null) {
                    location = loc
                    showLocationEnabledNotification()
                } else {
                    showPermissionSnackbar()
                    binding.switchLocation.isChecked = false
                }
            }
        } else {
            requestPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun showLocationEnabledNotification() {
        AlertDialog.Builder(this).apply {
            setTitle(getString(R.string.location_enabled_title))
            setMessage(getString(R.string.location_enabled_message))
            setPositiveButton(getString(R.string.okay)) { dialog, _ ->
                dialog.dismiss()
            }
            create()
            show()
        }
    }

    private fun isGPSEnabled(): Boolean {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
    }

    private fun showEnableGPSDialog() {
        AlertDialog.Builder(this).apply {
            setTitle(getString(R.string.gps_dialog_tittle))
            setMessage(getString(R.string.gps_dialog_message))
            setPositiveButton(getString(R.string.next)) { _, _ ->
                val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                startActivity(intent)
            }
            create()
            show()
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showPermissionSnackbar() {
        Snackbar.make(binding.root, R.string.error_no_location, Snackbar.LENGTH_LONG)
            .setAction(R.string.enable) {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                startActivity(intent)
            }
            .show()
    }

    override fun onBackPressed() {
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra("fromUploadActivity", true)
        }
        startActivity(intent)
        super.onBackPressed()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    private fun bitmapToUri(bitmap: Bitmap): Uri? {
        val bytes = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val path = MediaStore.Images.Media.insertImage(
            contentResolver,
            bitmap,
            "Title",
            null
        )
        return Uri.parse(path)
    }
}
