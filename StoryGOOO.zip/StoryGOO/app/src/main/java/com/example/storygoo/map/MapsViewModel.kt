package com.example.storygoo.map

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.storygoo.pref.Result
import com.example.storygoo.pref.UserModel
import com.example.storygoo.pref.UserRepository
import com.example.storygoo.response.ListStoryItem

class MapsViewModel(private val repository: UserRepository) : ViewModel() {

    private val _storyListWithLocation = MediatorLiveData<Result<List<ListStoryItem>>>()
    val storyListWithLocation: LiveData<Result<List<ListStoryItem>>> = _storyListWithLocation

    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()
    }

    fun getStoriesWithLocation(token: String) {
        val liveData = repository.getStoriesWithLocation(token)
        _storyListWithLocation.addSource(liveData) { result ->
            _storyListWithLocation.value = result
        }
    }
}
