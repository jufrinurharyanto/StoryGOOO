package com.example.storygoo.signup

import androidx.lifecycle.ViewModel
import com.example.storygoo.pref.UserRepository

class SignupViewModel(private val repository: UserRepository) : ViewModel() {

    fun signup(name: String, email: String, password: String) =
        repository.signup(name, email, password)
}