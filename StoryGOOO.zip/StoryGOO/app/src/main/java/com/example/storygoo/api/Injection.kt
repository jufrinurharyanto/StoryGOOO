package com.example.storygoo.api

import android.content.Context
import com.example.storygoo.pref.UserPreference
import com.example.storygoo.pref.UserRepository
import com.example.storygoo.pref.dataStore

object Injection {
    fun provideRepository(context: Context): UserRepository {
        val pref = UserPreference.getInstance(context.dataStore)
        val apiService = ApiConfig.getApiService()
        return UserRepository.getInstance(apiService, pref)
    }
}