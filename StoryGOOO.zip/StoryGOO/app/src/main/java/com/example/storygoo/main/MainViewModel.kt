package com.example.storygoo.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.storygoo.pref.UserModel
import com.example.storygoo.pref.UserRepository
import com.example.storygoo.response.ListStoryItem
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class MainViewModel(private val repository: UserRepository) : ViewModel() {

    val storyList: LiveData<PagingData<ListStoryItem>> =
        repository.getStories(getToken()).cachedIn(viewModelScope)

    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    private fun getToken(): String {
        var token: String
        runBlocking {
            token = repository.getSession().firstOrNull()?.token ?: ""
        }
        return token
    }
}
