package com


import com.example.storygoo.response.ListStoryItem

object DataDummy {

    fun  generateDummyStoryResponse(): List<ListStoryItem> {
        val items: MutableList<ListStoryItem> = arrayListOf()
        for (i in 0..100) {
            val story = ListStoryItem(
                id = "story-KZF_HylnxoZ5PCTZ",
                name = "lioneljufrii",
                description = "test",
                photoUrl = "https://story-api.dicoding.dev/images/stories/photos-1718471361543_58525a3d918e27126102.jpg",
                createdAt = "2024-06-15T17:09:21.545Z",
                lat = -7.0320609,
                lon = 109.6172624

            )
            items.add(story)
        }
        return items
    }
}